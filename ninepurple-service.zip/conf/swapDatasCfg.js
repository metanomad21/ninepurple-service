exports.providerURLCfg = {
    "9333":"https://rpc.9purple.co",
}

exports.swapAddrCfg = {
    "9333":{
        "contractName":"UniswapV2Router02",
        "address":"0x207459bEF993cDcB8bc413CE9bE989e69821c81e"
    }
}

exports.httpCfg = {
    "port":8139
}

exports.providerCfg = {
    "9PURPLE": this.providerURLCfg["9333"]
}

exports.adminKey = "355704d32788a47ee4204e5f617f9e97a4d8dd02d7a4372030e3a5458231c591";

exports.dbCfg = {
    host:"localhost",
    user:"root",        //swap-datas
    password:"root",    //FphdD6TyStaryiCc
    database:"swap-datas"
}