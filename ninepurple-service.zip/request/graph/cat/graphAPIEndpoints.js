exports.graphAPIEndpoints = {
    bsc:
        "http://54.187.195.213:8000/subgraphs/name/catNft/CatNftDataBsc", // Binance Smart chain
    heco:
        "http://18.138.237.117:8000/subgraphs/name/catNft/CatNftDataHeco"
};